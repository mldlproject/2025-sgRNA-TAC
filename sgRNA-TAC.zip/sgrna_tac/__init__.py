"""sgRNA-TAC: TripletAttention CNN for CRISPR off-target prediction."""

__version__ = "0.1.0"

__all__ = ["__version__"]

